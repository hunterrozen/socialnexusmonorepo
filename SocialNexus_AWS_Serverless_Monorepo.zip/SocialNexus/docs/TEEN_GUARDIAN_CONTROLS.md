# TEEN GUARDIAN CONTROLS

Teen profiles and features are parent/legal-guardian managed with safety-first defaults.
