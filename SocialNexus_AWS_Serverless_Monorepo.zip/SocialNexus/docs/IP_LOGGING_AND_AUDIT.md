# IP LOGGING AND AUDIT

IP logs are admin-only and used for security, fraud prevention, moderation, abuse prevention, and audit trails.
