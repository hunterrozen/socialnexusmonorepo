# POLICY SYSTEM

Public landing shows policy summaries only. Full policies are available during signup, post-signup, and in-app. Must-read email is sent through SES.
