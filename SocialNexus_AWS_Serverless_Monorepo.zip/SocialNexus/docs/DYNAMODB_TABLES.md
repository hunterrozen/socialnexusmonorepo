# DYNAMODB TABLES

Tables use id as partition key in this starter. Production can add GSIs for userId, profileId, platform, communityId, and createdAt.
