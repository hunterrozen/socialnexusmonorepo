# AWS DEPLOYMENT

Deploy with CDK bootstrap and npm run deploy:infra. Configure SES verified sender before sending must-read emails.
