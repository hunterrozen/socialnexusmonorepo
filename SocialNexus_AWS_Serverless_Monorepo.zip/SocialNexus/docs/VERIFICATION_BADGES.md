# VERIFICATION BADGES

Includes Official, Creator, Up-and-Coming Creator, Everyday Verified, Community Helper, Trusted Neighbor, Student Creator, Local Creator, and LGBTQIA+ Rainbow Badge.
