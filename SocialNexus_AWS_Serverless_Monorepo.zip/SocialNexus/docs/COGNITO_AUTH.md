# COGNITO AUTH

Cognito User Pool supports email signup/login and groups for user, creator, moderator, admin, parent, guardian, and teen.
