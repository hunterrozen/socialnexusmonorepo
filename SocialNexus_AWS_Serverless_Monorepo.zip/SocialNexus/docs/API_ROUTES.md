# API ROUTES

Routes are defined in infra/lib/socialnexus-stack.ts and backed by services/api/src/handlers.
