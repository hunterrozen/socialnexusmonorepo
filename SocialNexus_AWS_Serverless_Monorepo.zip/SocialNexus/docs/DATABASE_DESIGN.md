# DATABASE DESIGN

DynamoDB tables include Users, Profiles, Posts, Comments, Messages, Conversations, Notifications, Media, Communities, Reports, Follows, Friends, VerificationBadges, VerificationRequests, Payments, IpLogs, PolicyAcceptances, PolicyEmails, and TeenGuardianControls.
