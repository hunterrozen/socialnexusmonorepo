# FRONTEND SETUP

Run npm run dev:web. Add Cognito and API values to apps/web environment variables.
