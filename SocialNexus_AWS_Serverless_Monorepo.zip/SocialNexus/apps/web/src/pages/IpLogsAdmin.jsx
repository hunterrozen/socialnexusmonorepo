export default function IpLogsAdmin(){return <section className='card'><h1>IP Logs</h1><p>Admin-only IP audit log viewer.</p></section>}
