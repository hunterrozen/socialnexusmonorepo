export default function Settings(){return <section className='card'><h1>Settings</h1><p>Privacy, profile, badges, professional mode, and policy versions.</p></section>}
