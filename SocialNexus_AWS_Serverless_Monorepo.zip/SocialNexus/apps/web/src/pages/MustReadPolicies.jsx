export default function MustReadPolicies(){return <section className='card'><h1>Must-Read Platform Rules</h1><p>Required after signup before full app access.</p></section>}
