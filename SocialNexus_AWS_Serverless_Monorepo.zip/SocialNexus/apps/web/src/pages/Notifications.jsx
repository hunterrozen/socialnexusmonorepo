export default function Notifications(){return <section className='card'><h1>Notifications</h1><p>Unified notifications.</p></section>}
