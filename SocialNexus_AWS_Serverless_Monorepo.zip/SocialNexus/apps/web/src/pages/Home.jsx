export default function Home(){return <section className='card'><h1>Home</h1><p>Unified feed, notifications, messages, and platform switching.</p></section>}
