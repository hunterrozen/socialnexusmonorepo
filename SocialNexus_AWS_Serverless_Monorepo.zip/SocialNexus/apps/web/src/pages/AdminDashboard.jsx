export default function AdminDashboard(){return <section className='card'><h1>Admin Dashboard</h1><p>Admin-only controls.</p></section>}
