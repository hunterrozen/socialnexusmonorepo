export default function Profile(){return <section className='card'><h1>Profile</h1><p>Main and secondary profiles with per-profile toggles.</p></section>}
