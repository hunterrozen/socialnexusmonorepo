export default function PolicyViewer(){return <section className='card'><h1>Policy Viewer</h1><p>Full in-app policies after signup.</p></section>}
