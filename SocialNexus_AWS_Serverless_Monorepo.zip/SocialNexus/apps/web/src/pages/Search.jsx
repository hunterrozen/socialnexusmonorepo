export default function Search(){return <section className='card'><h1>Search</h1><p>Search users, profiles, posts, and communities.</p></section>}
