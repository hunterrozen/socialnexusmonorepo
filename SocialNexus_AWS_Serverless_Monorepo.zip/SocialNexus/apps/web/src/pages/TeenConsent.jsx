export default function TeenConsent(){return <section className='card'><h1>Teen Consent</h1><p>Teen profile activation requires guardian approval.</p></section>}
