export default function GuardianDashboard(){return <section className='card'><h1>Guardian Dashboard</h1><p>Parent/legal guardian controls for teen profiles.</p></section>}
