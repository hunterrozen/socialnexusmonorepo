export default function Messages(){return <section className='card'><h1>Messages</h1><p>Unified and platform-specific messaging.</p></section>}
