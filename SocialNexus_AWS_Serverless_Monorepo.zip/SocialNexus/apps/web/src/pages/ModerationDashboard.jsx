export default function ModerationDashboard(){return <section className='card'><h1>Moderation Dashboard</h1><p>Reports, AI classification results, and content review.</p></section>}
