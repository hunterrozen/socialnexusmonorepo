export default function ReactionBar(props){return <div className='card'><strong>ReactionBar</strong></div>}
