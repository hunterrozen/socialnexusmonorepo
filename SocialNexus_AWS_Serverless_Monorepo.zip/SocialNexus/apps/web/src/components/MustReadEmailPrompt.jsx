export default function MustReadEmailPrompt(props){return <div className='card'><strong>MustReadEmailPrompt</strong></div>}
