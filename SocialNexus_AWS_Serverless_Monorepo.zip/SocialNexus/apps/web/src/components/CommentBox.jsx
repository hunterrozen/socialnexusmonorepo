export default function CommentBox(props){return <div className='card'><strong>CommentBox</strong></div>}
