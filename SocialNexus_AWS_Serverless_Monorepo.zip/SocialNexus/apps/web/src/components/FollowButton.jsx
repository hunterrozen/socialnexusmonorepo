export default function FollowButton(props){return <div className='card'><strong>FollowButton</strong></div>}
