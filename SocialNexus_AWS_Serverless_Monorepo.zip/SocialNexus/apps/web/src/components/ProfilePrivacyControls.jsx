export default function ProfilePrivacyControls(props){return <div className='card'><strong>ProfilePrivacyControls</strong></div>}
