export default function ProfileCard(props){return <div className='card'><strong>ProfileCard</strong></div>}
