export default function PostCard(props){return <div className='card'><strong>PostCard</strong></div>}
