export default function GuardianControlToggle(props){return <div className='card'><strong>GuardianControlToggle</strong></div>}
