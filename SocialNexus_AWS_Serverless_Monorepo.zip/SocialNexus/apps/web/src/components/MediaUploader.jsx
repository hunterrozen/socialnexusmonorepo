export default function MediaUploader(props){return <div className='card'><strong>MediaUploader</strong></div>}
