export default function VerificationBadge(props){return <div className='card'><strong>VerificationBadge</strong></div>}
