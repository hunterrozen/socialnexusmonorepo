export default function FriendButton(props){return <div className='card'><strong>FriendButton</strong></div>}
