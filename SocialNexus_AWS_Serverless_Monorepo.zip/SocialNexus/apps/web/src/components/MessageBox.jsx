export default function MessageBox(props){return <div className='card'><strong>MessageBox</strong></div>}
