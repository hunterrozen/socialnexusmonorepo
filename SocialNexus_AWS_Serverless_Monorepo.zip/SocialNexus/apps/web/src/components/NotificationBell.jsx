export default function NotificationBell(props){return <div className='card'><strong>NotificationBell</strong></div>}
