import React, { useState } from 'react';
import Landing from './pages/Landing.jsx';
import Home from './pages/Home.jsx';
import Login from './auth/Login.jsx';
import Signup from './auth/Signup.jsx';
import LinkUpHome from './platforms/linkup/LinkUpHome.jsx';
import VibeHome from './platforms/vibe/VibeHome.jsx';
import ThreadLineHome from './platforms/threadline/ThreadLineHome.jsx';
import PulseHome from './platforms/pulse/PulseHome.jsx';
import ReddlineHome from './platforms/reddline/ReddlineHome.jsx';
import MainLayout from './layout/MainLayout.jsx';

const routes = {
  landing: <Landing />,
  login: <Login />,
  signup: <Signup />,
  home: <Home />,
  linkup: <LinkUpHome />,
  vibe: <VibeHome />,
  threadline: <ThreadLineHome />,
  pulse: <PulseHome />,
  reddline: <ReddlineHome />
};

export default function App() {
  const [route, setRoute] = useState('landing');
  const page = routes[route] || routes.landing;
  return <MainLayout onNavigate={setRoute}>{React.cloneElement(page, { onNavigate: setRoute })}</MainLayout>;
}
