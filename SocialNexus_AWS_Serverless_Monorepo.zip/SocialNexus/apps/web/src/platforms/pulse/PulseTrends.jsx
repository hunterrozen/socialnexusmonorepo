export default function PulseTrends(){return <section className='card'><h1>Pulse Trends</h1><p>Trending topics.</p></section>}
