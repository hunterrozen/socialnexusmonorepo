export default function PulsePost(){return <section className='card'><h1>Pulse Post</h1><p>Public conversation.</p></section>}
