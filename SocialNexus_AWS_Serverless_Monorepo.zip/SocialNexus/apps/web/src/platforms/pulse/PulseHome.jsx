export default function PulseHome(){return <section className='card'><h1>Pulse</h1><p>Fast public posts, trends, hashtags, reposts, quote posts.</p></section>}
