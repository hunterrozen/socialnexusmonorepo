export default function VibeUpload(){return <section className='card'><h1>Vibe Upload</h1><p>Media upload.</p></section>}
