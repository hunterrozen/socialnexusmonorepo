export default function VibeHome(){return <section className='card'><h1>Vibe</h1><p>Photos, reels, stories, creators, likes, comments, and saves.</p></section>}
