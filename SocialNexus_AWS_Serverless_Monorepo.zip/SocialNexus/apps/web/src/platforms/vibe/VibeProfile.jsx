export default function VibeProfile(){return <section className='card'><h1>Vibe Profile</h1><p>Creator and follower profile.</p></section>}
