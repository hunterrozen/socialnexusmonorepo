export default function VibeStories(){return <section className='card'><h1>Vibe Stories</h1><p>Stories and expiring media.</p></section>}
