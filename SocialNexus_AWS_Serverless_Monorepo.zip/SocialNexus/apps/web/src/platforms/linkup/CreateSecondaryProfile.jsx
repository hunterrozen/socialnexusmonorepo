export default function CreateSecondaryProfile(){return <section className='card'><h1>Create Secondary Profile</h1><p>Create multiple profiles under one account.</p></section>}
