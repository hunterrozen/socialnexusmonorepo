export default function EditSecondaryProfile(){return <section className='card'><h1>Edit Secondary Profile</h1><p>Privacy, friend requests, messaging, following, and badges.</p></section>}
