export default function LinkUpFriends(){return <section className='card'><h1>LinkUp Friends</h1><p>Friend requests can be toggled by each profile.</p></section>}
