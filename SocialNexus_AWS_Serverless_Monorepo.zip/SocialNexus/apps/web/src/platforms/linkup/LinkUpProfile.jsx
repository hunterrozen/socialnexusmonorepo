export default function LinkUpProfile(){return <section className='card'><h1>LinkUp Profile</h1><p>Main and secondary profile identity controls.</p></section>}
