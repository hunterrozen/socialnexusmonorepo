export default function LinkUpHome(){return <section className='card'><h1>LinkUp</h1><p>Facebook-style social area without Pages. Uses secondary profiles instead.</p></section>}
