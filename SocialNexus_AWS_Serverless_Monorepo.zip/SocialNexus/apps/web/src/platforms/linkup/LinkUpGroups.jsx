export default function LinkUpGroups(){return <section className='card'><h1>LinkUp Groups</h1><p>Groups, posts, comments, and reactions.</p></section>}
