export default function ProfileSwitcher(){return <section className='card'><h1>Profile Switcher</h1><p>Switch between main and secondary profiles.</p></section>}
