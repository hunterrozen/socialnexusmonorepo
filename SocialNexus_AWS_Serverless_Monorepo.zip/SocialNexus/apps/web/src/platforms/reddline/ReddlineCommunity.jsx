export default function ReddlineCommunity(){return <section className='card'><h1>Reddline Community</h1><p>Community rules and moderator tools.</p></section>}
