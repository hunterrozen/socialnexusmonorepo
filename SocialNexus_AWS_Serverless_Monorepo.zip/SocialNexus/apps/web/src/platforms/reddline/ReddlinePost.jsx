export default function ReddlinePost(){return <section className='card'><h1>Reddline Post</h1><p>Community post and vote controls.</p></section>}
