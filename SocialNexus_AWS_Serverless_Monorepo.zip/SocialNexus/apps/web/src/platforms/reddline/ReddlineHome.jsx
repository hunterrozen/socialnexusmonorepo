export default function ReddlineHome(){return <section className='card'><h1>Reddline</h1><p>Communities, forums, moderators, voting, and cross-posting.</p></section>}
