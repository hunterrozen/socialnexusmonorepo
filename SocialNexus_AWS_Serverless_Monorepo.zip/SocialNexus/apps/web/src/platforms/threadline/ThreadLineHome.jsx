export default function ThreadLineHome(){return <section className='card'><h1>ThreadLine</h1><p>Text posts, replies, reposts, public and private threads.</p></section>}
