export default function ThreadLinePost(){return <section className='card'><h1>ThreadLine Post</h1><p>Conversation detail.</p></section>}
