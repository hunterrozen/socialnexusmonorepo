export default function ThreadLineReplies(){return <section className='card'><h1>ThreadLine Replies</h1><p>Replies and nested conversation.</p></section>}
