export default function TopNav(){return <div className='card'>SocialNexus Top Navigation</div>}
