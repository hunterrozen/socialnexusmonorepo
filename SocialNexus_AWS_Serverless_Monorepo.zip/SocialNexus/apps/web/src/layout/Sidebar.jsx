import React from 'react';
export default function Sidebar({ onNavigate }) {
  const items = [['landing','Landing'],['signup','Sign up'],['login','Login'],['home','Home'],['linkup','LinkUp'],['vibe','Vibe'],['threadline','ThreadLine'],['pulse','Pulse'],['reddline','Reddline']];
  return <aside className="sidebar"><h2>SocialNexus</h2>{items.map(([id,label]) => <button key={id} onClick={() => onNavigate(id)}>{label}</button>)}</aside>;
}
