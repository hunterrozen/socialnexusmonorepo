export default function MobileNav(){return <div className='card'>Mobile Navigation</div>}
