import React from 'react';
import Sidebar from './Sidebar.jsx';
export default function MainLayout({ children, onNavigate }) {
  return <div className="app-shell"><Sidebar onNavigate={onNavigate} /><main className="main">{children}</main></div>;
}
