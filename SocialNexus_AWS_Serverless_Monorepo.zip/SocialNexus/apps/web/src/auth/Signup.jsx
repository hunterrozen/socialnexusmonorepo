import React, { useState } from 'react';
import { sendMustReadEmail } from '../config/api.js';
export default function Signup(){
  const [emailOptIn, setEmailOptIn] = useState(false);
  return <section className="card"><h1>Create your SocialNexus account</h1>
    <p>Public visitors see summaries only. Full policies are shown during and after signup.</p>
    <label><input type="checkbox"/> I agree to the Terms of Service.</label><br/>
    <label><input type="checkbox"/> I agree to the Privacy Policy.</label><br/>
    <label><input type="checkbox"/> I agree to the Community Standards.</label><br/>
    <label><input type="checkbox"/> I understand the platform safety rules.</label><br/>
    <h3>Must-read email</h3>
    <p>Would you like us to send you a must-read email with the most important SocialNexus rules, safety policies, privacy information, and verification requirements?</p>
    <label><input checked={emailOptIn} onChange={e=>setEmailOptIn(e.target.checked)} type="checkbox"/> Yes, send me the must-read email</label>
    <br/><button onClick={() => emailOptIn && sendMustReadEmail().catch(console.error)}>Create account</button>
  </section>;
}
