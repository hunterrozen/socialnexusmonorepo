export default function ConfirmAccount(){return <section className='card'><h1>Confirm Account</h1></section>}
