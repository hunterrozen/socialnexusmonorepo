import React from 'react';
export default function Login(){ return <section className="card"><h1>Login</h1><p>Use Cognito email login. Add passkey/WebAuthn-ready flow here.</p><input placeholder="Email"/><button>Continue</button></section>; }
