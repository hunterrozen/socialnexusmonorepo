const API_URL = import.meta.env.VITE_API_URL || '';
export async function api(path, options = {}) {
  const token = localStorage.getItem('socialnexus_token');
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(data?.error || `Request failed: ${res.status}`);
  return data;
}
export const getPublicPolicySummary = () => api('/policies/public-summary');
export const acceptPolicies = (payload) => api('/policies/accept', { method: 'POST', body: JSON.stringify(payload) });
export const sendMustReadEmail = () => api('/policies/send-must-read-email', { method: 'POST', body: JSON.stringify({}) });
