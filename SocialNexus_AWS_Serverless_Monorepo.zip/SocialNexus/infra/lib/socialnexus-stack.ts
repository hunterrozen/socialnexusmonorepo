import * as path from 'path';
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigwv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as integrations from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import * as authorizers from 'aws-cdk-lib/aws-apigatewayv2-authorizers';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as origins from 'aws-cdk-lib/aws-cloudfront-origins';
import * as iam from 'aws-cdk-lib/aws-iam';

const tables = ['Users','Profiles','Posts','Comments','Messages','Conversations','Notifications','Media','Communities','Reports','Follows','Friends','VerificationBadges','VerificationRequests','Payments','IpLogs','PolicyAcceptances','PolicyEmails','TeenGuardianControls'];

export class SocialNexusStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const tableMap: Record<string, dynamodb.Table> = {};
    for (const name of tables) {
      tableMap[name] = new dynamodb.Table(this, `${name}Table`, {
        partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
        billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
        removalPolicy: cdk.RemovalPolicy.DESTROY,
        pointInTimeRecovery: true
      });
    }

    const userPool = new cognito.UserPool(this, 'SocialNexusUserPool', {
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      autoVerify: { email: true },
      passwordPolicy: { minLength: 12, requireDigits: true, requireLowercase: true, requireUppercase: true, requireSymbols: true }
    });
    const userPoolClient = new cognito.UserPoolClient(this, 'SocialNexusUserPoolClient', { userPool, authFlows: { userPassword: true, userSrp: true } });
    for (const group of ['user','creator','moderator','admin','parent','guardian','teen']) new cognito.CfnUserPoolGroup(this, `${group}Group`, { userPoolId: userPool.userPoolId, groupName: group });

    const mediaBucket = new s3.Bucket(this, 'SocialNexusMediaBucket', { blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL, cors: [{ allowedMethods: [s3.HttpMethods.PUT, s3.HttpMethods.GET], allowedOrigins: ['*'], allowedHeaders: ['*'] }], removalPolicy: cdk.RemovalPolicy.DESTROY, autoDeleteObjects: true });
    const frontendBucket = new s3.Bucket(this, 'SocialNexusFrontendBucket', { blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL, removalPolicy: cdk.RemovalPolicy.DESTROY, autoDeleteObjects: true });
    const distribution = new cloudfront.Distribution(this, 'SocialNexusFrontendDistribution', { defaultBehavior: { origin: origins.S3BucketOrigin.withOriginAccessControl(frontendBucket) }, defaultRootObject: 'index.html' });

    const api = new apigwv2.HttpApi(this, 'SocialNexusHttpApi', { corsPreflight: { allowHeaders: ['authorization','content-type','x-active-profile-id'], allowMethods: [apigwv2.CorsHttpMethod.ANY], allowOrigins: ['*'] } });
    const jwtAuthorizer = new authorizers.HttpUserPoolAuthorizer('SocialNexusJwtAuthorizer', userPool, { userPoolClients: [userPoolClient] });

    const env: Record<string,string> = {
      USERS_TABLE: tableMap.Users.tableName,
      PROFILES_TABLE: tableMap.Profiles.tableName,
      POSTS_TABLE: tableMap.Posts.tableName,
      COMMENTS_TABLE: tableMap.Comments.tableName,
      MESSAGES_TABLE: tableMap.Messages.tableName,
      CONVERSATIONS_TABLE: tableMap.Conversations.tableName,
      NOTIFICATIONS_TABLE: tableMap.Notifications.tableName,
      MEDIA_TABLE: tableMap.Media.tableName,
      COMMUNITIES_TABLE: tableMap.Communities.tableName,
      REPORTS_TABLE: tableMap.Reports.tableName,
      FOLLOWS_TABLE: tableMap.Follows.tableName,
      FRIENDS_TABLE: tableMap.Friends.tableName,
      VERIFICATION_BADGES_TABLE: tableMap.VerificationBadges.tableName,
      VERIFICATION_REQUESTS_TABLE: tableMap.VerificationRequests.tableName,
      PAYMENTS_TABLE: tableMap.Payments.tableName,
      IP_LOGS_TABLE: tableMap.IpLogs.tableName,
      POLICY_ACCEPTANCES_TABLE: tableMap.PolicyAcceptances.tableName,
      POLICY_EMAILS_TABLE: tableMap.PolicyEmails.tableName,
      TEEN_GUARDIAN_CONTROLS_TABLE: tableMap.TeenGuardianControls.tableName,
      MEDIA_BUCKET: mediaBucket.bucketName,
      POLICY_EMAIL_FROM: process.env.POLICY_EMAIL_FROM || 'no-reply@example.com',
      STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY || 'sk_test_replace'
    };

    const mk = (name: string, handlerFile: string) => {
      const fn = new lambda.Function(this, name, {
        runtime: lambda.Runtime.NODEJS_20_X,
        handler: `${handlerFile}.handler`,
        code: lambda.Code.fromAsset(path.join(__dirname, '../../services/api/src')),
        environment: env,
        timeout: cdk.Duration.seconds(15)
      });
      Object.values(tableMap).forEach(t => t.grantReadWriteData(fn));
      mediaBucket.grantReadWrite(fn);
      fn.addToRolePolicy(new iam.PolicyStatement({ actions: ['ses:SendEmail','ses:SendRawEmail'], resources: ['*'] }));
      return fn;
    };

    const route = (method: apigwv2.HttpMethod, routePath: string, handlerFile: string, secured = true) => {
      const fn = mk(routePath.replace(/[^A-Za-z0-9]/g, '') || 'Root', `handlers/${handlerFile}`);
      api.addRoutes({ path: routePath, methods: [method], integration: new integrations.HttpLambdaIntegration(`${handlerFile}Integration`, fn), authorizer: secured ? jwtAuthorizer : undefined });
    };

    route(apigwv2.HttpMethod.GET, '/policies/public-summary', 'policies/getPublicSummary', false);
    route(apigwv2.HttpMethod.GET, '/policies/full', 'policies/getFullPolicies');
    route(apigwv2.HttpMethod.GET, '/policies/versions', 'policies/getPolicyVersions');
    route(apigwv2.HttpMethod.POST, '/policies/accept', 'policies/acceptPolicies');
    route(apigwv2.HttpMethod.POST, '/policies/send-must-read-email', 'policies/sendMustReadEmail');

    const routeDefs: [apigwv2.HttpMethod,string,string][] = [
      [apigwv2.HttpMethod.GET,'/me','auth/me'],[apigwv2.HttpMethod.POST,'/users','users/createUser'],[apigwv2.HttpMethod.GET,'/users/{id}','users/getUser'],[apigwv2.HttpMethod.PATCH,'/users/{id}','users/updateUser'],[apigwv2.HttpMethod.GET,'/users/search','users/searchUsers'],
      [apigwv2.HttpMethod.POST,'/profiles','profiles/createProfile'],[apigwv2.HttpMethod.GET,'/profiles','profiles/listProfiles'],[apigwv2.HttpMethod.GET,'/profiles/{id}','profiles/getProfile'],[apigwv2.HttpMethod.PATCH,'/profiles/{id}','profiles/updateProfile'],[apigwv2.HttpMethod.DELETE,'/profiles/{id}','profiles/deleteProfile'],[apigwv2.HttpMethod.POST,'/profiles/{id}/switch','profiles/switchProfile'],[apigwv2.HttpMethod.PATCH,'/profiles/{id}/friend-requests','profiles/updateFriendRequests'],[apigwv2.HttpMethod.PATCH,'/profiles/{id}/messaging','profiles/updateMessaging'],[apigwv2.HttpMethod.PATCH,'/profiles/{id}/following','profiles/updateFollowing'],
      [apigwv2.HttpMethod.POST,'/posts','posts/createPost'],[apigwv2.HttpMethod.GET,'/posts','posts/listPosts'],[apigwv2.HttpMethod.GET,'/posts/{id}','posts/getPost'],[apigwv2.HttpMethod.DELETE,'/posts/{id}','posts/deletePost'],[apigwv2.HttpMethod.POST,'/posts/{id}/react','posts/reactToPost'],
      [apigwv2.HttpMethod.POST,'/comments','comments/createComment'],[apigwv2.HttpMethod.GET,'/comments/{postId}','comments/listComments'],[apigwv2.HttpMethod.DELETE,'/comments/{id}','comments/deleteComment'],
      [apigwv2.HttpMethod.POST,'/messages','messages/sendMessage'],[apigwv2.HttpMethod.GET,'/messages','messages/listMessages'],[apigwv2.HttpMethod.GET,'/messages/conversations/{id}','messages/getConversation'],
      [apigwv2.HttpMethod.POST,'/notifications','notifications/createNotification'],[apigwv2.HttpMethod.GET,'/notifications','notifications/listNotifications'],[apigwv2.HttpMethod.PATCH,'/notifications/{id}/read','notifications/markRead'],
      [apigwv2.HttpMethod.POST,'/media/upload-url','media/createUploadUrl'],[apigwv2.HttpMethod.POST,'/media/save','media/saveMediaRecord'],
      [apigwv2.HttpMethod.POST,'/linkup/friends/request','linkup/createFriendRequest'],[apigwv2.HttpMethod.POST,'/linkup/friends/accept','linkup/acceptFriendRequest'],[apigwv2.HttpMethod.GET,'/linkup/friends','linkup/listFriends'],[apigwv2.HttpMethod.POST,'/linkup/groups','linkup/createGroup'],[apigwv2.HttpMethod.GET,'/linkup/groups','linkup/listGroups'],
      [apigwv2.HttpMethod.POST,'/vibe/stories','vibe/createStory'],[apigwv2.HttpMethod.GET,'/vibe/stories','vibe/listStories'],[apigwv2.HttpMethod.POST,'/vibe/reels','vibe/createReel'],[apigwv2.HttpMethod.GET,'/vibe/reels','vibe/listReels'],
      [apigwv2.HttpMethod.POST,'/threadline/threads','threadline/createThread'],[apigwv2.HttpMethod.GET,'/threadline/threads','threadline/listThreads'],[apigwv2.HttpMethod.POST,'/threadline/threads/{id}/reply','threadline/replyToThread'],
      [apigwv2.HttpMethod.POST,'/pulse/posts','pulse/createPulse'],[apigwv2.HttpMethod.GET,'/pulse/feed','pulse/listPulseFeed'],[apigwv2.HttpMethod.GET,'/pulse/trends','pulse/listTrends'],
      [apigwv2.HttpMethod.POST,'/reddline/communities','reddline/createCommunity'],[apigwv2.HttpMethod.GET,'/reddline/communities','reddline/listCommunities'],[apigwv2.HttpMethod.POST,'/reddline/posts','reddline/createCommunityPost'],[apigwv2.HttpMethod.POST,'/reddline/posts/{id}/vote','reddline/votePost'],
      [apigwv2.HttpMethod.POST,'/verification/request','verification/requestVerification'],[apigwv2.HttpMethod.GET,'/verification/badges','verification/listBadges'],[apigwv2.HttpMethod.GET,'/verification/requests','verification/listRequests'],[apigwv2.HttpMethod.PATCH,'/verification/requests/{id}','verification/reviewRequest'],[apigwv2.HttpMethod.POST,'/verification/lgbtqia-rainbow/request','verification/requestLgbtqiaRainbowBadge'],[apigwv2.HttpMethod.DELETE,'/verification/lgbtqia-rainbow','verification/removeLgbtqiaRainbowBadge'],
      [apigwv2.HttpMethod.POST,'/teen/guardian/link','teen/linkGuardian'],[apigwv2.HttpMethod.GET,'/teen/guardian/controls/{teenUserId}','teen/getGuardianControls'],[apigwv2.HttpMethod.PATCH,'/teen/guardian/controls/{teenUserId}','teen/updateGuardianControls'],[apigwv2.HttpMethod.POST,'/teen/guardian/approve-profile','teen/approveTeenProfile'],[apigwv2.HttpMethod.POST,'/teen/guardian/deny-profile','teen/denyTeenProfile'],[apigwv2.HttpMethod.POST,'/teen/guardian/pause-profile','teen/pauseTeenProfile'],[apigwv2.HttpMethod.POST,'/teen/guardian/revoke-feature','teen/revokeTeenFeature'],[apigwv2.HttpMethod.GET,'/guardian/teens','teen/listGuardianTeens'],
      [apigwv2.HttpMethod.POST,'/moderation/report','moderation/reportContent'],[apigwv2.HttpMethod.GET,'/moderation/reports','moderation/reportContent'],[apigwv2.HttpMethod.PATCH,'/moderation/reports/{id}','moderation/reviewReport'],
      [apigwv2.HttpMethod.GET,'/admin/ip-logs','admin/listIpLogs'],[apigwv2.HttpMethod.GET,'/admin/audit-logs','admin/getAuditLogs'],
      [apigwv2.HttpMethod.POST,'/payments/stripe/checkout','payments/createStripeCheckout'],[apigwv2.HttpMethod.POST,'/payments/creator-payout','payments/createCreatorPayout'],
      [apigwv2.HttpMethod.POST,'/ai/detect-edited-media','ai/detectEditedMedia'],[apigwv2.HttpMethod.POST,'/ai/classify-content','ai/classifyContent']
    ];
    routeDefs.forEach(([m,p,h]) => route(m,p,h));

    new cdk.CfnOutput(this, 'ApiUrl', { value: api.apiEndpoint });
    new cdk.CfnOutput(this, 'UserPoolId', { value: userPool.userPoolId });
    new cdk.CfnOutput(this, 'UserPoolClientId', { value: userPoolClient.userPoolClientId });
    new cdk.CfnOutput(this, 'FrontendDistributionDomain', { value: distribution.distributionDomainName });
    new cdk.CfnOutput(this, 'MediaBucketName', { value: mediaBucket.bucketName });
  }
}
