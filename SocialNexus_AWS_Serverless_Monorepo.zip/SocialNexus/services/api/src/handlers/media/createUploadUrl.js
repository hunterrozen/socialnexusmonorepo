import { v4 as uuid } from 'uuid';
import { ok, badRequest, parseBody } from '../../lib/response.js';
import { getAuth, activeProfileId } from '../../lib/auth.js';
import { createPresignedUploadUrl } from '../../lib/s3.js';
import { logForEvent } from '../../lib/ipLogger.js';
export async function handler(event) {
  try {
    const auth = getAuth(event);
    const body = parseBody(event);
    await logForEvent(event, 'create-media-upload-url');
    const ext = (body.filename || 'upload.bin').split('.').pop();
    const key = `${auth.userId}/${activeProfileId(event) || 'main'}/${uuid()}.${ext}`;
    const uploadUrl = await createPresignedUploadUrl({ key, contentType: body.contentType || 'application/octet-stream' });
    return ok({ uploadUrl, key });
  } catch (error) { return badRequest(error); }
}
