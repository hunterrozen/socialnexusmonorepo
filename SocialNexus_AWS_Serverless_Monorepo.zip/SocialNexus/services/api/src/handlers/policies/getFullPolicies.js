import { ok } from '../../lib/response.js';
import { CURRENT_POLICY_VERSIONS } from '../../lib/policyVersions.js';
export async function handler() { return ok({ versions: CURRENT_POLICY_VERSIONS, policies: { terms: 'Full Terms of Service are shown inside the app.', privacy: 'Full Privacy Policy is shown inside the app.', communityStandards: 'Full Community Standards are shown inside the app.', safetyRules: 'Full Safety Rules are shown inside the app.' } }); }
