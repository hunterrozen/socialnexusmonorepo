import { ok } from '../../lib/response.js';
import { CURRENT_POLICY_VERSIONS } from '../../lib/policyVersions.js';
export async function handler() { return ok(CURRENT_POLICY_VERSIONS); }
