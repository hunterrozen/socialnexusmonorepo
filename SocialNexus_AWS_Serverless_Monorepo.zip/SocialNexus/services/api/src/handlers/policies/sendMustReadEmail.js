import { v4 as uuid } from 'uuid';
import { created, badRequest } from '../../lib/response.js';
import { putItem } from '../../lib/dynamo.js';
import { getAuth } from '../../lib/auth.js';
import { sendPolicyEmail } from '../../lib/ses.js';
import { CURRENT_POLICY_VERSIONS } from '../../lib/policyVersions.js';
import { logForEvent } from '../../lib/ipLogger.js';
export async function handler(event) {
  try {
    const auth = getAuth(event);
    await logForEvent(event, 'send-must-read-policy-email');
    const html = `<h1>Important: Must-Read SocialNexus Rules and Safety Information</h1><p>Read the Terms, Privacy Policy, Community Standards, Teen Safety, Verification Rules, LGBTQIA+ Rainbow Badge eligibility, IP logging notice, reporting and appeals, and creator monetization rules inside SocialNexus.</p>`;
    const sesMessageId = await sendPolicyEmail({ to: auth.email, subject: 'Important: Must-Read SocialNexus Rules and Safety Information', html });
    const item = { emailId: uuid(), userId: auth.userId, email: auth.email, policyVersion: CURRENT_POLICY_VERSIONS.termsVersion, deliveryStatus: 'sent', sentAt: new Date().toISOString(), sesMessageId, createdAt: new Date().toISOString() };
    await putItem(process.env.POLICY_EMAILS_TABLE, item);
    return created({ item });
  } catch (error) { return badRequest(error); }
}
