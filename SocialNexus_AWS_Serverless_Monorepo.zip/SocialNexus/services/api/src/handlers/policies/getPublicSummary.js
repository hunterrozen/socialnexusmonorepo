import { ok } from '../../lib/response.js';
import { PUBLIC_POLICY_SUMMARY, CURRENT_POLICY_VERSIONS } from '../../lib/policyVersions.js';
export async function handler() { return ok({ summary: PUBLIC_POLICY_SUMMARY, versions: CURRENT_POLICY_VERSIONS }); }
