import { v4 as uuid } from 'uuid';
import { created, badRequest, parseBody } from '../../lib/response.js';
import { putItem } from '../../lib/dynamo.js';
import { getAuth } from '../../lib/auth.js';
import { getSourceIp, getUserAgent, logForEvent } from '../../lib/ipLogger.js';
import { CURRENT_POLICY_VERSIONS } from '../../lib/policyVersions.js';
export async function handler(event) {
  try {
    const auth = getAuth(event);
    const body = parseBody(event);
    if (!body.acceptTerms || !body.acceptPrivacy || !body.acceptCommunityStandards || !body.acceptSafetyRules) throw new Error('All policy acceptance checkboxes are required.');
    await logForEvent(event, 'accept-policies');
    const item = { acceptanceId: uuid(), userId: auth.userId, ...CURRENT_POLICY_VERSIONS, acceptedAt: new Date().toISOString(), ipAddress: getSourceIp(event), userAgent: getUserAgent(event), signupRequestId: event.requestContext?.requestId || uuid(), createdAt: new Date().toISOString() };
    await putItem(process.env.POLICY_ACCEPTANCES_TABLE, item);
    return created({ item });
  } catch (error) { return badRequest(error); }
}
