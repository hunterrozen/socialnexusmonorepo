import { v4 as uuid } from 'uuid';
import { ok, created, badRequest, parseBody, forbidden } from '../../lib/response.js';
import { putItem, getItem, scanTable, updateItem, deleteItem } from '../../lib/dynamo.js';
import { getAuth, requireAdmin, activeProfileId } from '../../lib/auth.js';
import { logForEvent, getSourceIp, getUserAgent } from '../../lib/ipLogger.js';

const TABLE = process.env.PROFILES_TABLE;

export async function handler(event) {
  try {
    const auth = getAuth(event);
    const body = {};
    const id = event.pathParameters?.id || event.pathParameters?.postId || event.pathParameters?.teenUserId; const result = await getItem(TABLE, { id }); return ok({ item: result.Item || null });
  } catch (error) {
    if (String(error.message || error).includes('Admin role required')) return forbidden(error.message);
    return badRequest(error);
  }
}
