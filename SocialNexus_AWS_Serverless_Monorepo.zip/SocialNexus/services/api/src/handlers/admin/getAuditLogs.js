import { ok, badRequest, forbidden } from '../../lib/response.js';
import { scanTable } from '../../lib/dynamo.js';
import { requireAdmin } from '../../lib/auth.js';
export async function handler(event) { try { requireAdmin(event); const result = await scanTable(process.env.IP_LOGS_TABLE, 100); return ok({ items: result.Items || [] }); } catch (error) { return String(error.message).includes('Admin') ? forbidden(error.message) : badRequest(error); } }
