import { created, badRequest, parseBody } from '../../lib/response.js';
import { stripe } from '../../lib/stripe.js';
import { getAuth } from '../../lib/auth.js';
import { logForEvent } from '../../lib/ipLogger.js';
export async function handler(event) {
  try {
    const auth = getAuth(event);
    const body = parseBody(event);
    await logForEvent(event, 'create-stripe-checkout');
    const session = await stripe.checkout.sessions.create({ mode: body.mode || 'subscription', customer_email: auth.email, line_items: [{ price: body.priceId, quantity: 1 }], success_url: body.successUrl, cancel_url: body.cancelUrl });
    return created({ checkoutUrl: session.url, sessionId: session.id });
  } catch (error) { return badRequest(error); }
}
