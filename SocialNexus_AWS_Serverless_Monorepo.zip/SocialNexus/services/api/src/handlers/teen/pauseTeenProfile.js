import { v4 as uuid } from 'uuid';
import { ok, created, badRequest, parseBody, forbidden } from '../../lib/response.js';
import { putItem, getItem, scanTable, updateItem, deleteItem } from '../../lib/dynamo.js';
import { getAuth, requireAdmin, activeProfileId } from '../../lib/auth.js';
import { logForEvent, getSourceIp, getUserAgent } from '../../lib/ipLogger.js';

const TABLE = process.env.TEEN_GUARDIAN_CONTROLS_TABLE;

export async function handler(event) {
  try {
    const auth = getAuth(event);
    const body = parseBody(event);
    await logForEvent(event, 'pause-teen-profile');
    const id = event.pathParameters?.id || event.pathParameters?.teenUserId;
    const result = await updateItem(TABLE, { id }, { ...body, updatedAt: new Date().toISOString() });
    return ok({ item: result.Attributes });
  } catch (error) {
    if (String(error.message || error).includes('Admin role required')) return forbidden(error.message);
    return badRequest(error);
  }
}
