import { v4 as uuid } from 'uuid';
import { created, badRequest, parseBody, forbidden } from '../../lib/response.js';
import { putItem } from '../../lib/dynamo.js';
import { getAuth, activeProfileId } from '../../lib/auth.js';
import { logForEvent } from '../../lib/ipLogger.js';
export async function handler(event) {
  try {
    const auth = getAuth(event);
    const body = parseBody(event);
    if (!body.lgbtqiaSelfIdentified || !body.interestedInProfileFieldCompleted || !body.outAndProudBadgeOptIn) return forbidden('Rainbow badge requires opt-in, self-identification, completed private eligibility field, and visible out-and-proud badge consent.');
    await logForEvent(event, 'request-lgbtqia-rainbow-badge');
    const item = { requestId: uuid(), userId: auth.userId, profileId: activeProfileId(event), badgeId: 'lgbtqia-rainbow', requestStatus: 'pending', privateFieldVisibility: body.interestedInProfileFieldVisibility || 'hidden', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    await putItem(process.env.VERIFICATION_REQUESTS_TABLE, item);
    return created({ item });
  } catch (error) { return badRequest(error); }
}
