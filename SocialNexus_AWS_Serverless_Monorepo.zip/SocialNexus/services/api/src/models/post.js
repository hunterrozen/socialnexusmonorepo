export const postModel = { name: 'post' };
