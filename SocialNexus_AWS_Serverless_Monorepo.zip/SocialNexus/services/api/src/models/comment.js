export const commentModel = { name: 'comment' };
