export const verificationModel = { name: 'verification' };
