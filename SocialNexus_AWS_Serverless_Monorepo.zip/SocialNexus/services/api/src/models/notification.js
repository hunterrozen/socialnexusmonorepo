export const notificationModel = { name: 'notification' };
