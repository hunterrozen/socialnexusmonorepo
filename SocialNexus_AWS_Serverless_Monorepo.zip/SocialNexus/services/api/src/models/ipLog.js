export const ipLogModel = { name: 'ipLog' };
