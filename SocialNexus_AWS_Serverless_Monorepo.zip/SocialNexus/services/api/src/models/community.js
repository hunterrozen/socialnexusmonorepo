export const communityModel = { name: 'community' };
