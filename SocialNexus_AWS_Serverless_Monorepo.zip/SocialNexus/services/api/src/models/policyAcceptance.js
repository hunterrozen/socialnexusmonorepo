export const policyAcceptanceModel = { name: 'policyAcceptance' };
