export const mediaModel = { name: 'media' };
