export const teenGuardianControlsModel = { name: 'teenGuardianControls' };
