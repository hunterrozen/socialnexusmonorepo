export const messageModel = { name: 'message' };
