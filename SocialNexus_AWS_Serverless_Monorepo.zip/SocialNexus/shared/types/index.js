export const SOCIALNEXUS_VERSION = '1.0.0';
