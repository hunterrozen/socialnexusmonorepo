export function required(value, name) {
  if (value === undefined || value === null || value === '') throw new Error(`${name} is required`);
  return value;
}
export function nowIso() { return new Date().toISOString(); }
