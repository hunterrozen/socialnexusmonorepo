export const POLICY_TYPES = Object.freeze(['terms', 'privacy', 'communityStandards', 'safetyRules', 'verificationRules', 'teenSafetyRules', 'creatorMonetizationRules', 'reportingAppealsPolicy']);
