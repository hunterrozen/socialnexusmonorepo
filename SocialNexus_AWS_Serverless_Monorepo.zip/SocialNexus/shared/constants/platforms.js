export const PLATFORMS = Object.freeze({ LINKUP: 'linkup', VIBE: 'vibe', THREADLINE: 'threadline', PULSE: 'pulse', REDDLINE: 'reddline' });
