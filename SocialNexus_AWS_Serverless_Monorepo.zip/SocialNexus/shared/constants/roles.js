export const ROLES = Object.freeze(['user', 'creator', 'moderator', 'admin', 'parent', 'guardian', 'teen']);
